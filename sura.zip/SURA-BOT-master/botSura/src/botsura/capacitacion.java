/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package botsura;

/**
 *
 * @author japb1
 */
public class capacitacion {
    public int avance;
    
    //aqui se invocaran los temas
    //aqui se guardara el avance de la capacitacion
    //creo que aqui se invocara el quiz
    
    
    
    
}
